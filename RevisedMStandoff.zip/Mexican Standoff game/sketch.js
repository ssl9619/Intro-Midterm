let backgroundImg;
let spriteSheetImg;
let spriteSheetImgFlipped;
let broncoFont;
let gameStarted;            // Whether or not the game has started (pre countdown)
let fire;                   // Whether or not the countdown reached the fire point
let player1;
let player2;
// let frameRateNumber = 300; 60 fps is the maximum
let buttonBoolean;
let initialFrameCount;
let randomNumber; // 0-2

// TODO sounds


function preload() {
  backgroundImg = loadImage("images/wild west town picture.png")
  spriteSheetImg = loadImage("images/cowboy dueling sprite sheet.png");
  spriteSheetImgFlipped = loadImage("images/cowboy duel sprite sheet flipped.png");
  broncoFont = loadFont("font/BroncoPersonalUse.ttf");
}
 





function setup() {
  createCanvas(600, 600);
  player1 = new player(1);
  player2 = new player(2);
  gameStarted = false;
  fire = false;
  buttonBoolean = false;
  initialFrameCount = 0;
  randomNumber = random(0,2);
}



function draw() {
  background(0);

  gamePlay();
  
}



function gamePlay() {
  // Background
  push();
    noStroke();
    fill(214,148,52);
    image(backgroundImg, -75,-225);
    backgroundImg.resize(0, 0)
    rect(0, 460,width,200);
  pop();

  
  player1.drawPlayer();
  player2.drawPlayer();
  
  text(frameCount, 30,30);
  text(initialFrameCount, 30,60);
  
  if(buttonBoolean) {
    countdownFunctionality();
  }
  



}



// TODO Game start functionality
// TODO Restart game functionality
function keyPressed() {
  buttonBoolean = !buttonBoolean;

  if(buttonBoolean) {
    initialFrameCount = frameCount;
  }
}


// x must be between 0 and 2 
function spriteSheet(x, spriteSheetImage) {
  // x indicates which sprite to output

  spriteWidth = 240; // Each sprite is 240 pixels wide
  spriteHeight = 448; // Each sprite is 448 pixels high
  // Note: Image ratio is 
  // 120, 224
  // 60, 112
  // 30, 56
  


  desiredX = spriteWidth * x;
  desiredY = 0; // made it a variable so that it makes more sense when looking at the function

  return spriteSheetImage.get(desiredX, desiredY, spriteWidth, spriteHeight);


}




// Numbers 1-4
// 4 = fire
function countDownDraw(number) {
  // possible numbers
  // 1,2,3,4
  // 123 obv
  // 4 = fire!
  
  
    let posX = width/2;
    let posY = 90;

    if(number == 4) {
      push();
        rectMode(CENTER);
        strokeWeight(5);
        stroke(0);
        fill(255, 0, 0);
        rect(posX, posY-23, 140, 80, 10,10,10,10);
      pop();
    
      push();
        textAlign(CENTER);
        textFont(broncoFont);
        // stroke(200,0,0);
        // strokeWeight(8)
        fill(255);
        textSize(72);
        text("FIRE!", posX, posY);
      pop();

    } else {

      // Rectangle background
      push();
        rectMode(CENTER);
        // strokeWeight(3);
        // stroke(50);
        fill(0);
        rect(posX, posY-23, 80, 80, 10,10,10,10);
      pop();
    
      push();
        textAlign(CENTER);
        textFont(broncoFont);
        stroke(200,0,0);
        strokeWeight(8)
        fill(255);
        textSize(72);
        text(number, posX, posY);
      pop();

    }


    
  
}



function countdownFunctionality() {
// frame rate is 60

  let x = 2.5;
  let xSecond = 60 * x; 

  let firstSecond =   initialFrameCount + xSecond * 1;
  let secondSecond =  initialFrameCount + xSecond * 2;
  let thirdSecond =   initialFrameCount + xSecond * (3+randomNumber)

  if(frameCount < firstSecond) {
    countDownDraw(1);
  }

  if(frameCount > firstSecond && frameCount < secondSecond) {
    countDownDraw(2);
  }

  if(frameCount > secondSecond && frameCount < thirdSecond) {
    countDownDraw(3);
  }

  if(frameCount > thirdSecond) {
    countDownDraw(4);
  }

  // if(frameCount > firstSecond) {
  //   countDownDraw(1);

  // }

  // if(frameCount > firstSecond && frameCount < secondSecond) {
  //   countDownDraw(2);
  // }



}


class player {
  

  constructor(playerNumber) {
    // Player 1 or 2
    // Current state refers to the sprite selected
    this.playerNumber = playerNumber; // Can only be 1 or 2
    this.currentState = 0; // Values between 0 and 2 can be changed to display the correct sprite
    this.intendedSpriteSheet // whether the flipped one will be used or the normal one
    this.won = false
    this.lost = false; 
    

    this.posY = 450;
    switch(playerNumber) {
      case 1:
        this.posX = 80;
        this.intendedSpriteSheet = spriteSheetImg
        break;
      case 2:
        this.posX = 480
        this.posY += 4; // this is because the flipped image is a bit weird
        this.intendedSpriteSheet = spriteSheetImgFlipped;
        break;
      default:
        break;
    }
    
  }

    drawPlayer() {
      let resizeX = 60;
      let resizeY = 112;

      let playerSprite;
      playerSprite = spriteSheet(this.currentState, this.intendedSpriteSheet);
      playerSprite.resize(resizeX, resizeY);
      image(playerSprite, this.posX, this.posY);

    }

    
}