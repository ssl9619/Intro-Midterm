let frameRateNumber;
let cd;
let countdownElement = new countdown();

function setup() {
  createCanvas(400, 400);
  frameRateNumber = 60; // fps
}

let keyBoolean = false;

function draw() {
  frameRate(frameRateNumber);
  background(220);


  text(frameCount, 30,30);


  // 5 seconds then etc

  // let xSeconds = frameRateNumber * 2.5;
  // let first5 = frameCount > xSeconds;
  // let second5 = frameCount > xSeconds*2;
  // let third5 = frameCount > xSeconds*3;
  
  // if(first5 && !second5) {
  //   text("1", width/2, height/2);
  // }

  // if(second5 && !third5) {
  //   text("2", width/2, height/2);
  // }

  // if(third5) {
  //   text("3", width/2, height/2);
  // }


  // let randomSeconds = frameRateNumber * random(1,5);
  


}

function countdown (initialFrameCount) {
  let xSeconds = frameRateNumber * 2.5;
  let firstSecondMark = initialFrameCount + (xSeconds * 1);
  let secondSecondMark = initialFrameCount + (xSeconds * 2);
  let thirdSecondMark = initialFrameCount + (xSeconds * 3);
  let finalRandomSecondMark = thirdSecondMark + (xSeconds * random(1,5));

  switch(frameCount) {
    
  }

}

function keyPressed() {
  keyBoolean = !keyBoolean;

  if(keyBoolean) {
    countdownElement.count(frameCount);
  }
}

class countdown {
  constructor() {
    // take the frame count
    // 1 sec
    // 2 sec
    // 3 sec
    // x sec --> fire
  }

  count(frameCount0) {
    let second = frameRateNumber; // just to make my life easier to understand
    push();
    
    
    pop();
  }
}
