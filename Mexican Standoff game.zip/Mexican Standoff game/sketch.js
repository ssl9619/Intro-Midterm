let backgroundImg;
let spriteSheetImg;
let spriteSheetImgFlipped;
let broncoFont;
let gameStarted;            // Whether or not the game has started (pre countdown)
let fire;                   // Whether or not the countdown reached the fire point
// TODO sounds

function preload() {
  backgroundImg = loadImage("images/wild west town picture.png")
  spriteSheetImg = loadImage("images/cowboy dueling sprite sheet.png");
  spriteSheetImgFlipped = loadImage("images/cowboy duel sprite sheet flipped.png");
  broncoFont = loadFont("font/BroncoPersonalUse.ttf");
}
 
let player1;
let player2;
let frameRateNumber = 300;

function setup() {
  createCanvas(600, 600);
  player1 = new player(1);
  player2 = new player(2);
  gameStarted = false;
  fire = false;
}

function draw() {
  frameRate(frameRateNumber);
  background(0);

  gamePlay();
  
}



function gamePlay() {
  // Background
  push();
    noStroke();
    fill(214,148,52);
    image(backgroundImg, -75,-225);
    backgroundImg.resize(0, 0)
    rect(0, 460,width,200);
  pop();

  
  player1.drawPlayer();
  player2.drawPlayer();
  
  
  


}

// x must be between 0 and 2 
function spriteSheet(x, spriteSheetImage) {
  // x indicates which sprite to output

  spriteWidth = 240; // Each sprite is 240 pixels wide
  spriteHeight = 448; // Each sprite is 448 pixels high
  // Note: Image ratio is 
  // 120, 224
  // 60, 112
  // 30, 56
  


  desiredX = spriteWidth * x;
  desiredY = 0; // made it a variable so that it makes more sense when looking at the function

  return spriteSheetImage.get(desiredX, desiredY, spriteWidth, spriteHeight);


}

function countDown(frameCount0) {
  // Takes the frameCount then when it is equal to one second
  let oneSecond = frameRateNumber;

  push();
    let textPosX = width/2;
    let textPosY = 40;

    textSize(32);
    if(frameCount == frameCount0 + oneSecond) {
      textFont(broncoFont);
      textAlign(CENTER);
      text("1", textPosX, textPosY);
    }
  pop();

}

class player {
  

  constructor(playerNumber) {
    // Player 1 or 2
    // Current state refers to the sprite selected
    this.playerNumber = playerNumber; // Can only be 1 or 2
    this.currentState = 0; // Values between 0 and 2 can be changed to display the correct sprite
    this.intendedSpriteSheet // whether the flipped one will be used or the normal one
    this.won = false
    this.lost = false; 
    

    this.posY = 450;
    switch(playerNumber) {
      case 1:
        this.posX = 80;
        this.intendedSpriteSheet = spriteSheetImg
        break;
      case 2:
        this.posX = 480
        this.posY += 4; // this is because the flipped image is a bit weird
        this.intendedSpriteSheet = spriteSheetImgFlipped;
        break;
      default:
        break;
    }
    
  }

    drawPlayer() {
      let resizeX = 60;
      let resizeY = 112;

      let playerSprite;
      playerSprite = spriteSheet(this.currentState, this.intendedSpriteSheet);
      playerSprite.resize(resizeX, resizeY);
      image(playerSprite, this.posX, this.posY);

    }

    
}