// Goal
// Scene management
// Basically overarching brain over everything
// classes for each scene as well
// Note to self: I can call on these variables and functions from any other javascript file as well
let sceneManagment;
let screenNumber; // I've misnamed this and a lot of other variables screen instead of scene but it is what it is, I'm not changing it
let mainB;      // Boolean to enable the main menu
let playB;      // Boolean to enable the play menu
let tutorialB;  // Boolean to enable the tutorial menu
let creditsB;

// Images
let logoFont;
let backIcon;


function preload() {
  logoFont = loadFont("font/BroncoPersonalUse.ttf");
  // logo = loadImage("images/resizedTitle.png");
  // backIcon = loadImage("images/resizedBackIcon");
}

function setup() {
  createCanvas(600, 600);
  sceneManagment = new sceneManagmentClass();
  screenNumber = 0;

}

function draw() {
  // background(220);

  // selects the screen
  sceneManagment.selectScreen(screenNumber);


}

// detects mouse hovering within a rectangle area
function detectIfMouse(posX, posY, w, h) {
  // if(mouseX < )
  let halfWidth = w/2;
  let halfHeight = h/2;

  if(mouseX < posX + halfWidth && 
    mouseX  > posX - halfWidth && 
    mouseY  < posY + halfHeight &&
    mouseY  > posY - halfHeight
    ) {
      return true;

  }

  return false;

}

// detects if mouse clicked while hovering within a rectangle area
// may or may not use this
function detectMouseClicked(posX, posY, w, h) {

  let hovering = detectIfMouse(posX, posY, w, h);

  if(hovering && mouseIsPressed) {
    return true;
  }

  return false;
}


// may make a function which just selects between the scenes for you