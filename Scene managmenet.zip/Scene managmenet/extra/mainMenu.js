function mainMenuFunction() {
    // TODO Interesting background & title image
    let xPos;
    let yPos;
    let rectW;
    let rectH;

    background(255, 253, 208);

    // title
    push();
        textSize(42);
        textAlign(CENTER);


        xPos = width/2;
        yPos = 100;
        textFont(logoFont);
        textSize(62);
        
        text('MEXICAN\nSTANDOFF\n1.0', xPos, yPos);
        // image(logo, width/2-(imgWidth/2),50);
        

    pop();

    // play button
    push();
        rectMode(CENTER);

        xPos = width/2;
        yPos = 310; 
        rectW = 150;
        rectH = 50;
        let playButtonHover = detectIfMouse(xPos, yPos, rectW, rectH);


        // hovering color change
        if(playButtonHover) {
            fill(0);
            rectW += 10;
            rectH += 10;
            strokeWeight(2);
            stroke(200, 0, 0);
        } else {
            fill(255);
        }
        rect(xPos, yPos, rectW, rectH, 15, 15, 15, 15);

        // Text
        push();
            if(playButtonHover) {
                fill(200, 0, 0);
                textStyle(BOLD);
            } else {
                fill(0);
            }
            textFont(logoFont);
            
            textAlign(CENTER);
            textSize(32);
            text('Play', width/2, yPos+10);
        pop();

        // click functionality
        let click = detectMouseClicked(xPos, yPos, rectW, rectH);
        if(click) {
            screenNumber = 1;
        }

    pop();
    
    // tutorial button
    push();
        rectMode(CENTER);

        xPos = width/2;
        yPos = 400;
        rectW = 150;
        rectH = 50;
        let tutorialButtonHover = detectIfMouse(xPos, yPos, rectW, rectH);

        coefficient = 0.1;
        destination = rectW + 10;
        // background
        if(tutorialButtonHover) {
            fill(0);
            rectW += 10;
            rectH += 10;
            strokeWeight(2);
            stroke(200, 0, 0);
        } else {
            fill(255);
        }
        rect(xPos, yPos, rectW, rectH, 15, 15, 15, 15);


        // Text
        push();
            if(tutorialButtonHover) {
                fill(255);
                textStyle(BOLD);
            } else {
                fill(0);
            }
            // fill(255);
            textAlign(CENTER);
            textFont(logoFont);
            textSize(32);
            text('Help', width/2, 410);
        pop();
        
        click = detectMouseClicked(xPos, yPos, rectW, rectH);
        if(click) {
            screenNumber = 2;
        }

    pop();

    push();
        rectMode(CENTER);

        xPos = width/2;
        yPos = 500;
        rectW = 150;
        rectH = 50;
        let creditsMenuButtonHover = detectIfMouse(xPos, yPos, rectW, rectH);

        // background
        if(creditsMenuButtonHover) {
            fill(0);
            rectW += 10;
            rectH += 10;
            strokeWeight(2);
            stroke(200, 0, 0);
        } else {
            fill(255);
        }
        rect(xPos, yPos, rectW, rectH, 15, 15, 15, 15);


        // Text
        push();
            if(creditsMenuButtonHover) {
                fill(255);
                textStyle(BOLD);
                strokeWeight(2);
                stroke(200, 0, 0);
            } else {
                fill(0);
            }
            // fill(255);
            textAlign(CENTER);
            textSize(32);
            textFont(logoFont);
            text('Credits', xPos, yPos+10);
            
        pop();

        click = detectMouseClicked(xPos, yPos, rectW, rectH);
        if(click) {
            screenNumber = 3;
        }
        

    pop();
        

    // may include some background elements

}