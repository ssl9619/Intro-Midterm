function gameMenuFunction() {
    // TODO (1) The actual game
    background(255);
    text("insert game here", width/2, height/2);
}