function tutorialMenuFunction() {
    // TODO The actual tutorial
    background(255);
    text("insert tutorial here", width/2, height/2);
}