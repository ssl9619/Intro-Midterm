function creditsMenuFunction() {
    // TODO Interesting background and/or font (optional)
    background(255);

    push();

        textAlign(CENTER);
        text("Made by Saeed Lootah\nssl9619\n\nSpecial thanks to:\nProfessor Aaron Sherwood\nPi Ko", width/2, height/2);

    pop();

}