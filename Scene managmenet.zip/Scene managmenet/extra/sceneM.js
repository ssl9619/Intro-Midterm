class sceneManagmentClass {
    
    
    
    constructor(x) {
        this.x = x;
        this.selectScreen(x); // sets the initial value for x
    }

    // X is a value from 0-3
    // if x = 0, main menu
    // if x = 1, game screen
    // if x = 2, tutorial
    // if x = 3, credits screen

    // This function will be called every time in the draw function
    // Any other function can change the screen by changing sceneManagementClass.x
    selectScreen(x) {
        // This is a switch statement it just goes through a lot of values 
        // the same way an if statement would but its nicer to look at
        switch(x) {
            case 0:
                this.mainMenu();
                break;
            case 1:
                this.gameScreen();
                break;
            case 2:
                this.tutorialScreen();
                break;
            case 3: 
                this.creditsScreen();
                break;
            default:
                // returns an error if x is not one of the aformentioned values
                return -1;
        }
    }

    // In each of these will also be the functionality
    // x = 0
    mainMenu() {
        mainMenuFunction();
    }
    
    // x = 1
    tutorialScreen() {
        tutorialMenuFunction();
    }

    // x = 2
    gameScreen() {
        gameMenuFunction();
    }

    // x = 3
    creditsScreen() {
        creditsMenuFunction();
    }

}